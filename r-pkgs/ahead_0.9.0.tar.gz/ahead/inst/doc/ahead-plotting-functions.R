## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----include=FALSE------------------------------------------------------------
library(ahead)
library(fpp)

## -----------------------------------------------------------------------------
obj <- ahead::ridge2f(fpp::insurance, h = 7, type_pi = "blockbootstrap", B = 10, 
                      block_length = 5)

## ----fig.width=7.2------------------------------------------------------------
plot(obj, selected_series = "Quotes", type = "sims", 
     main = "Predictive simulations \n for Quotes")
plot(obj, selected_series = "Quotes", type = "dist", 
     main = "Predictive simulation \n for Quotes")

## ----fig.width=7.2------------------------------------------------------------
plot(obj, selected_series = "TV.advert", type = "sims", 
     main = "Predictive simulation \n for TV.advert")
plot(obj, selected_series = "TV.advert", type = "dist", 
     main = "Predictive simulation \n for TV.advert")

