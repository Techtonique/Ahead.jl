## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----include=FALSE------------------------------------------------------------
library(ahead)
library(fpp)
library(datasets)
library(randomForest)
library(e1071)

## -----------------------------------------------------------------------------

# Plotting forecasts
# With a Random Forest regressor, an horizon of 20, 
# and a 95% prediction interval
plot(dynrmf(fdeaths, h=20, level=95, fit_func = randomForest::randomForest,
      fit_params = list(ntree = 50), predict_func = predict))

# With a Support Vector Machine regressor, an horizon of 20, 
# and a 95% prediction interval
plot(dynrmf(fdeaths, h=20, level=95, fit_func = e1071::svm,
fit_params = list(kernel = "linear"), predict_func = predict))

plot(dynrmf(Nile, h=20, level=95, fit_func = randomForest::randomForest,
      fit_params = list(ntree = 50), predict_func = predict))

plot(dynrmf(Nile, h=20, level=95, fit_func = e1071::svm,
fit_params = list(kernel = "linear"), predict_func = predict))


## -----------------------------------------------------------------------------
# Forecast using ridge2
# With 2 time series lags, an horizon of 10, 
# and a 95% prediction interval
 fit_obj_ridge2 <- ahead::ridge2f(fpp::insurance, lags = 2,
                                  h = 10, level = 95)


# Forecast using VAR
 fit_obj_VAR <- ahead::varf(fpp::insurance, lags = 2,
                            h = 10, level = 95)

 
# Plotting forecasts 
# fpp::insurance contains 2 time series, Quotes and TV.advert 
 plot(fit_obj_ridge2, "Quotes")
 plot(fit_obj_VAR, "Quotes")
 plot(fit_obj_ridge2, "TV.advert")
 plot(fit_obj_VAR, "TV.advert")

